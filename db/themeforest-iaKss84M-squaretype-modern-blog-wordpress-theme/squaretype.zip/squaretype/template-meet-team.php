<?php
/**
 * Template Name: Meet The Team
 * Template Post Type: page
 *
 * @package Squaretype
 */

esc_html__( 'Meet The Team', 'squaretype' );

// Include default page template.
get_template_part( 'page' );
