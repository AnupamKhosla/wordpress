=== Squaretype ===
Contributors: Code Supply Co.
Requires at least: WordPress 4.7
Tested up to: WordPress 5.0-trunk
Version: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: one-column, two-columns, right-sidebar, left-sidebar, custom-colors, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, post-formats, rtl-language-support, sticky-post, theme-options, threaded-comments, translation-ready

== Description ==

Squaretype is a WordPress starter theme by Code Supply Co. for expert bloggers and magazines.

== Changelog ==

= 1.0 =
* Released: May 1, 2018

Initial release
